import * as CANNON from 'cannon';

export class PhysicsEngine {
    constructor(settings) {
        this.settings = settings;
        this.world = null;
        this.bodies = new Map();
        this.constraints = new Map();
        this.timeStep = 1 / 60;
        this.maxSubSteps = 3;
        
        this.init();
    }

    init() {
        // Create physics world
        this.world = new CANNON.World();
        this.world.gravity.set(0, 0, 0); // Top-down 2D physics
        this.world.broadphase = new CANNON.NaiveBroadphase();
        this.world.solver.iterations = 10;
        
        // Set up materials and contact properties
        this.setupMaterials();
        
        // Create arena boundaries
        this.createArena();
    }

    setupMaterials() {
        // Default material
        this.defaultMaterial = new CANNON.Material('default');
        
        // Bot material
        this.botMaterial = new CANNON.Material('bot');
        
        // Projectile material
        this.projectileMaterial = new CANNON.Material('projectile');
        
        // Wall material
        this.wallMaterial = new CANNON.Material('wall');
        
        // Contact materials
        const botWallContact = new CANNON.ContactMaterial(
            this.botMaterial,
            this.wallMaterial,
            {
                friction: 0.3,
                restitution: 0.3
            }
        );
        
        const projectileWallContact = new CANNON.ContactMaterial(
            this.projectileMaterial,
            this.wallMaterial,
            {
                friction: 0.1,
                restitution: 0.8
            }
        );
        
        const botProjectileContact = new CANNON.ContactMaterial(
            this.botMaterial,
            this.projectileMaterial,
            {
                friction: 0.1,
                restitution: 0.2
            }
        );
        
        this.world.addContactMaterial(botWallContact);
        this.world.addContactMaterial(projectileWallContact);
        this.world.addContactMaterial(botProjectileContact);
    }

    createArena() {
        const arenaSize = 2000;
        const wallThickness = 50;
        
        // Create arena walls
        const walls = [
            // Top wall
            { x: 0, y: -arenaSize/2 - wallThickness/2, width: arenaSize, height: wallThickness },
            // Bottom wall
            { x: 0, y: arenaSize/2 + wallThickness/2, width: arenaSize, height: wallThickness },
            // Left wall
            { x: -arenaSize/2 - wallThickness/2, y: 0, width: wallThickness, height: arenaSize },
            // Right wall
            { x: arenaSize/2 + wallThickness/2, y: 0, width: wallThickness, height: arenaSize }
        ];
        
        walls.forEach((wall, index) => {
            const shape = new CANNON.Box(new CANNON.Vec3(wall.width/2, wall.height/2, 25));
            const body = new CANNON.Body({ mass: 0, material: this.wallMaterial });
            body.addShape(shape);
            body.position.set(wall.x, wall.y, 0);
            
            this.world.add(body);
            this.bodies.set(`wall_${index}`, body);
        });
        
        // Add some obstacles in the arena
        this.createObstacles();
    }

    createObstacles() {
        const obstacles = [
            { x: 200, y: 200, width: 100, height: 100 },
            { x: -200, y: -200, width: 100, height: 100 },
            { x: 300, y: -300, width: 80, height: 150 },
            { x: -400, y: 100, width: 120, height: 80 }
        ];
        
        obstacles.forEach((obstacle, index) => {
            const shape = new CANNON.Box(new CANNON.Vec3(obstacle.width/2, obstacle.height/2, 25));
            const body = new CANNON.Body({ mass: 0, material: this.wallMaterial });
            body.addShape(shape);
            body.position.set(obstacle.x, obstacle.y, 0);
            
            this.world.add(body);
            this.bodies.set(`obstacle_${index}`, body);
        });
    }

    createBot(id, x, y, config = {}) {
        const {
            width = 60,
            height = 80,
            mass = 100,
            maxSpeed = 300,
            acceleration = 800,
            rotationSpeed = 4
        } = config;
        
        // Create bot body
        const shape = new CANNON.Box(new CANNON.Vec3(width/2, height/2, 15));
        const body = new CANNON.Body({ mass, material: this.botMaterial });
        body.addShape(shape);
        body.position.set(x, y, 0);
        
        // Add custom properties
        body.userData = {
            id,
            type: 'bot',
            health: 100,
            energy: 100,
            maxSpeed,
            acceleration,
            rotationSpeed,
            width,
            height,
            weapons: [],
            shields: false
        };
        
        // Linear and angular damping for realistic movement
        body.linearDamping = 0.1;
        body.angularDamping = 0.3;
        
        this.world.add(body);
        this.bodies.set(id, body);
        
        return body;
    }

    createProjectile(id, x, y, angle, speed, config = {}) {
        const {
            size = 5,
            mass = 1,
            damage = 20,
            lifetime = 3000,
            type = 'bullet'
        } = config;
        
        const shape = new CANNON.Sphere(size);
        const body = new CANNON.Body({ mass, material: this.projectileMaterial });
        body.addShape(shape);
        body.position.set(x, y, 0);
        
        // Set velocity
        const velocity = new CANNON.Vec3(
            Math.cos(angle) * speed,
            Math.sin(angle) * speed,
            0
        );
        body.velocity.copy(velocity);
        
        body.userData = {
            id,
            type: 'projectile',
            damage,
            lifetime,
            projectileType: type,
            createdAt: Date.now()
        };
        
        this.world.add(body);
        this.bodies.set(id, body);
        
        // Auto-remove after lifetime
        setTimeout(() => {
            this.removeBody(id);
        }, lifetime);
        
        return body;
    }

    updateBot(id, input) {
        const body = this.bodies.get(id);
        if (!body || body.userData.type !== 'bot') return;
        
        const { movement, targeting, firing, special, shield } = input;
        const userData = body.userData;
        
        // Update movement
        if (movement.x !== 0 || movement.y !== 0) {
            const force = new CANNON.Vec3(
                movement.x * userData.acceleration,
                movement.y * userData.acceleration,
                0
            );
            body.applyForce(force, body.position);
            
            // Limit speed
            const speed = body.velocity.length();
            if (speed > userData.maxSpeed) {
                body.velocity.scale(userData.maxSpeed / speed, body.velocity);
            }
        }
        
        // Update rotation based on movement or targeting
        if (targeting.x !== 0 || targeting.y !== 0) {
            const targetAngle = Math.atan2(targeting.y - body.position.y, targeting.x - body.position.x);
            const currentAngle = body.quaternion.toAxisAngle(new CANNON.Vec3(0, 0, 1))[0];
            
            let angleDiff = targetAngle - currentAngle;
            
            // Normalize angle difference
            while (angleDiff > Math.PI) angleDiff -= 2 * Math.PI;
            while (angleDiff < -Math.PI) angleDiff += 2 * Math.PI;
            
            // Apply rotation
            if (Math.abs(angleDiff) > 0.1) {
                const rotationForce = Math.sign(angleDiff) * userData.rotationSpeed;
                body.angularVelocity.z = rotationForce;
            }
        }
        
        // Handle firing
        if (firing && userData.energy > 10) {
            this.fireBotWeapon(id);
            userData.energy -= 10;
        }
        
        // Handle special abilities
        if (special && userData.energy > 30) {
            this.activateSpecialAbility(id);
            userData.energy -= 30;
        }
        
        // Handle shields
        userData.shields = shield;
        
        // Regenerate energy
        userData.energy = Math.min(100, userData.energy + 0.5);
    }

    fireBotWeapon(botId) {
        const body = this.bodies.get(botId);
        if (!body) return;
        
        const position = body.position;
        const angle = body.quaternion.toAxisAngle(new CANNON.Vec3(0, 0, 1))[0];
        
        // Calculate firing position (front of bot)
        const fireX = position.x + Math.cos(angle) * (body.userData.width / 2 + 10);
        const fireY = position.y + Math.sin(angle) * (body.userData.width / 2 + 10);
        
        // Create projectile
        const projectileId = `projectile_${Date.now()}_${Math.random()}`;
        this.createProjectile(projectileId, fireX, fireY, angle, 500, {
            damage: 25,
            lifetime: 2000
        });
        
        // Add recoil force
        const recoilForce = new CANNON.Vec3(
            -Math.cos(angle) * 50,
            -Math.sin(angle) * 50,
            0
        );
        body.applyImpulse(recoilForce, body.position);
    }

    activateSpecialAbility(botId) {
        const body = this.bodies.get(botId);
        if (!body) return;
        
        // Example: Burst fire
        const position = body.position;
        const baseAngle = body.quaternion.toAxisAngle(new CANNON.Vec3(0, 0, 1))[0];
        
        for (let i = 0; i < 5; i++) {
            setTimeout(() => {
                const spread = (Math.random() - 0.5) * 0.2;
                const angle = baseAngle + spread;
                
                const fireX = position.x + Math.cos(angle) * (body.userData.width / 2 + 10);
                const fireY = position.y + Math.sin(angle) * (body.userData.width / 2 + 10);
                
                const projectileId = `special_${Date.now()}_${i}`;
                this.createProjectile(projectileId, fireX, fireY, angle, 600, {
                    damage: 15,
                    lifetime: 1500,
                    type: 'special'
                });
            }, i * 100);
        }
    }

    checkCollisions() {
        const collisions = [];
        
        // Check all contact events
        this.world.contacts.forEach(contact => {
            const bodyA = contact.bi;
            const bodyB = contact.bj;
            
            if (bodyA.userData && bodyB.userData) {
                const collision = {
                    bodyA: bodyA.userData,
                    bodyB: bodyB.userData,
                    point: contact.getContactPoint(new CANNON.Vec3()),
                    normal: contact.ni
                };
                
                collisions.push(collision);
                
                // Handle specific collision types
                this.handleCollision(bodyA, bodyB, collision);
            }
        });
        
        return collisions;
    }

    handleCollision(bodyA, bodyB, collision) {
        // Projectile hit bot
        if ((bodyA.userData.type === 'projectile' && bodyB.userData.type === 'bot') ||
            (bodyA.userData.type === 'bot' && bodyB.userData.type === 'projectile')) {
            
            const projectile = bodyA.userData.type === 'projectile' ? bodyA : bodyB;
            const bot = bodyA.userData.type === 'bot' ? bodyA : bodyB;
            
            // Apply damage
            if (!bot.userData.shields) {
                bot.userData.health -= projectile.userData.damage;
            } else {
                bot.userData.health -= projectile.userData.damage * 0.3; // Reduced damage with shields
            }
            
            // Remove projectile
            this.removeBody(projectile.userData.id);
            
            // Emit collision event
            this.emit('botHit', {
                botId: bot.userData.id,
                damage: projectile.userData.damage,
                position: collision.point
            });
        }
        
        // Projectile hit wall
        if ((bodyA.userData.type === 'projectile' && !bodyB.userData) ||
            (bodyB.userData.type === 'projectile' && !bodyA.userData)) {
            
            const projectile = bodyA.userData.type === 'projectile' ? bodyA : bodyB;
            
            // Remove projectile on wall hit
            this.removeBody(projectile.userData.id);
            
            this.emit('projectileHitWall', {
                position: collision.point
            });
        }
    }

    removeBody(id) {
        const body = this.bodies.get(id);
        if (body) {
            this.world.remove(body);
            this.bodies.delete(id);
        }
    }

    update(deltaTime) {
        // Clean up old projectiles
        this.cleanupProjectiles();
        
        // Step physics simulation
        this.world.step(this.timeStep, deltaTime, this.maxSubSteps);
        
        // Check collisions
        const collisions = this.checkCollisions();
        
        return {
            bodies: Array.from(this.bodies.entries()).map(([id, body]) => ({
                id,
                position: { x: body.position.x, y: body.position.y },
                rotation: body.quaternion.toAxisAngle(new CANNON.Vec3(0, 0, 1))[0],
                velocity: { x: body.velocity.x, y: body.velocity.y },
                userData: body.userData
            })),
            collisions
        };
    }

    cleanupProjectiles() {
        const now = Date.now();
        const toRemove = [];
        
        this.bodies.forEach((body, id) => {
            if (body.userData.type === 'projectile') {
                if (now - body.userData.createdAt > body.userData.lifetime) {
                    toRemove.push(id);
                }
            }
        });
        
        toRemove.forEach(id => this.removeBody(id));
    }

    getBodyPosition(id) {
        const body = this.bodies.get(id);
        return body ? { x: body.position.x, y: body.position.y } : null;
    }

    getBodyRotation(id) {
        const body = this.bodies.get(id);
        return body ? body.quaternion.toAxisAngle(new CANNON.Vec3(0, 0, 1))[0] : 0;
    }

    // Event emitter functionality
    emit(event, data) {
        if (this.eventListeners && this.eventListeners[event]) {
            this.eventListeners[event].forEach(callback => callback(data));
        }
    }

    on(event, callback) {
        if (!this.eventListeners) {
            this.eventListeners = {};
        }
        if (!this.eventListeners[event]) {
            this.eventListeners[event] = [];
        }
        this.eventListeners[event].push(callback);
    }

    cleanup() {
        // Remove all bodies
        this.bodies.forEach((body, id) => {
            this.world.remove(body);
        });
        this.bodies.clear();
        
        // Clear constraints
        this.constraints.clear();
        
        // Clear event listeners
        this.eventListeners = {};
    }
}

